# API Specification

This document describes the API shape for Open Solar Payments. The OpenAPI draft is available at `openapi/openapi.yaml`.

All monetary values should include:

- `amount`
- `currency`
- `baseAmount`
- `baseCurrency`
- `exchangeRate`
- `rateTimestamp`

For Bitcoin and Lightning, implementations should also keep the fiat quote amount used at the time of invoice creation.

## Create Payment Intent

`POST /v1/payment-intents`

Creates a payment intent for a solar order, quote, cart, installer booking, or workorder.

Request:

```json
{
  "reference": "SUNTECORB-QUOTE-2026-00001",
  "sourceType": "solar_quote",
  "sourceId": "quote_123",
  "customer": {
    "name": "Ada Okafor",
    "email": "ada@example.com"
  },
  "amount": {
    "amount": 1250000,
    "currency": "NGN"
  },
  "paymentMethods": ["lightning", "bitcoin_onchain"],
  "metadata": {
    "systemKWp": 2.4,
    "installerRequired": true
  }
}
```

Response:

```json
{
  "id": "pi_01JZ_SOLAR",
  "reference": "SUNTECORB-QUOTE-2026-00001",
  "status": "requires_invoice",
  "amount": {
    "amount": 1250000,
    "currency": "NGN"
  },
  "createdAt": "2026-06-24T12:00:00Z"
}
```

## Create Invoice

`POST /v1/payment-intents/{id}/invoices`

Creates a Bitcoin or Lightning invoice for an existing payment intent.

Request:

```json
{
  "method": "lightning",
  "expiresInSeconds": 900,
  "description": "Suntecorb solar quote payment"
}
```

Response:

```json
{
  "invoiceId": "inv_01JZ_LIGHTNING",
  "paymentIntentId": "pi_01JZ_SOLAR",
  "method": "lightning",
  "status": "pending",
  "amount": {
    "amount": 1250000,
    "currency": "NGN",
    "btcAmount": "0.00714285",
    "sats": 714285
  },
  "paymentRequest": "lnbc7142850n1...",
  "expiresAt": "2026-06-24T12:15:00Z"
}
```

## Get Payment Status

`GET /v1/payment-intents/{id}`

Returns the current payment status, linked invoices, and settlement status.

## Provider Webhook

`POST /v1/webhooks/{provider}`

Receives payment status events from a provider such as BTCPay Server or a Lightning service.

The webhook handler should verify:

- provider signature
- event idempotency key
- invoice id
- expected amount
- expected payment hash or transaction id where applicable

## Create Settlement Record

`POST /v1/settlements`

Creates a settlement record after payment confirmation.

Request:

```json
{
  "paymentIntentId": "pi_01JZ_SOLAR",
  "settlementType": "installer_workorder",
  "workorderId": "wo_2026_00001",
  "merchantId": "merchant_suntecorb",
  "installerId": "installer_123",
  "amounts": {
    "customerPaid": 1250000,
    "merchantReceivable": 1100000,
    "installerReceivable": 150000,
    "currency": "NGN"
  }
}
```

## Create Receipt

`POST /v1/receipts`

Generates a receipt for a confirmed payment.

