# Architecture

Open Solar Payments is designed as a payment and settlement layer that can be embedded into solar commerce platforms without taking ownership of the entire business workflow.

## Core Principle

The module should handle money movement state, payment confirmation, receipts, and settlement records. The host application should continue to own products, user accounts, quotes, installer assignment, inventory, and fulfillment.

## System Context

```mermaid
flowchart LR
  User["Solar buyer"] --> App["Host solar app"]
  App --> PaymentAPI["Open Solar Payments API"]
  PaymentAPI --> Lightning["Lightning provider"]
  PaymentAPI --> Bitcoin["Bitcoin on-chain provider"]
  PaymentAPI --> Webhooks["Webhook handler"]
  Webhooks --> App
  App --> Workorder["Installer workorder"]
  PaymentAPI --> Receipt["Receipt and settlement record"]
  Installer["Installer"] --> Workorder
```

## Main Components

### Payment Intent

A payment intent represents the buyer's decision to pay for a solar quote, product cart, SunSplash deposit, installer service, or workorder-related charge.

### Invoice Adapter

An invoice adapter creates the actual payment request through a supported Bitcoin or Lightning provider.

Initial adapter targets:

- Lightning invoice provider
- BTCPay Server compatible flow
- On-chain Bitcoin address or invoice flow

### Payment Status Engine

Tracks whether a payment is pending, detected, confirmed, expired, failed, refunded, or manually reviewed.

### Webhook Receiver

Receives provider callbacks and updates payment status. Each webhook must be signature-verified where supported by the provider.

### Receipt Generator

Creates a merchant-facing and customer-facing receipt after confirmation.

### Settlement Record

Connects a confirmed payment to a solar order, workorder, installer payout record, or merchant reconciliation item.

## Reference Implementation Path

Suntecorb can use this module as the payment layer for:

- PowerLoad quote checkout
- Shop cart checkout
- SunSplash deposit payment
- Installer booking payment
- Workorder settlement records

The public module remains reusable by other solar and energy platforms.

