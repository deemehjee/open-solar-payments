# Payment Lifecycle

Open Solar Payments uses a simple payment state machine.

## States

```mermaid
stateDiagram-v2
  [*] --> requires_invoice
  requires_invoice --> pending
  pending --> detected
  detected --> confirmed
  pending --> expired
  pending --> failed
  detected --> review_required
  confirmed --> settled
  confirmed --> refunded
  review_required --> confirmed
  review_required --> failed
```

## State Definitions

### requires_invoice

The payment intent exists, but no Bitcoin or Lightning invoice has been generated.

### pending

An invoice has been generated and is waiting for payment.

### detected

A payment has been detected but is not fully confirmed or reconciled.

For Lightning, this may be a settled invoice waiting for host-app confirmation.

For on-chain Bitcoin, this may be a transaction seen in mempool.

### confirmed

The payment has been confirmed according to the method's rules.

Suggested defaults:

- Lightning: invoice settled
- Bitcoin on-chain: configurable confirmations, commonly 1 to 3 for ordinary solar commerce and higher for large orders

### review_required

The payment needs manual review because of a mismatch:

- underpayment
- overpayment
- expired invoice paid late
- unknown transaction
- webhook signature failure
- duplicate event

### settled

The payment has been reconciled with the merchant, installer, order, or workorder record.

### refunded

The payment was reversed or refunded according to merchant policy.

## Solar-Specific Flow

1. User completes PowerLoad, shop cart, or installer booking.
2. Host app creates payment intent.
3. User selects Lightning or Bitcoin.
4. Module creates invoice.
5. User pays.
6. Module confirms payment.
7. Host app receives webhook.
8. Host app marks order as paid.
9. If installer is involved, host app creates or updates workorder.
10. Module creates receipt and settlement record.

