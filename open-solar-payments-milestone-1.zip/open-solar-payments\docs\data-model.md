# Data Model

The module should store only the payment and settlement data needed for reconciliation. Host applications should store product, installer, inventory, and user profile data.

## PaymentIntent

| Field | Type | Notes |
| --- | --- | --- |
| id | string | Internal payment intent id |
| reference | string | Human-readable merchant reference |
| sourceType | enum | `solar_quote`, `shop_cart`, `installer_booking`, `sunsplash_deposit`, `workorder` |
| sourceId | string | Host application source id |
| customerName | string | Optional |
| customerEmail | string | Optional |
| amount | number | Fiat amount |
| currency | string | Fiat currency |
| status | enum | Payment lifecycle status |
| metadata | object | Host app metadata |
| createdAt | datetime | Creation time |
| updatedAt | datetime | Last update |

## Invoice

| Field | Type | Notes |
| --- | --- | --- |
| id | string | Internal invoice id |
| paymentIntentId | string | Related payment intent |
| method | enum | `lightning`, `bitcoin_onchain` |
| provider | string | Provider adapter name |
| paymentRequest | string | Lightning invoice or Bitcoin payment URI |
| btcAmount | string | BTC amount |
| sats | number | Satoshi amount |
| status | enum | Invoice status |
| expiresAt | datetime | Invoice expiry |
| providerInvoiceId | string | Provider invoice id |
| paymentHash | string | Lightning payment hash when available |
| txid | string | On-chain transaction id when available |

## PaymentEvent

| Field | Type | Notes |
| --- | --- | --- |
| id | string | Event id |
| invoiceId | string | Related invoice |
| provider | string | Event source |
| eventType | string | Provider event type |
| payload | object | Raw provider event payload |
| verified | boolean | Signature or authenticity verification |
| processedAt | datetime | Processing time |

## Settlement

| Field | Type | Notes |
| --- | --- | --- |
| id | string | Settlement id |
| paymentIntentId | string | Related payment intent |
| settlementType | enum | `merchant_order`, `installer_workorder`, `refund`, `manual_adjustment` |
| merchantId | string | Merchant id |
| installerId | string | Optional installer id |
| orderId | string | Optional order id |
| workorderId | string | Optional workorder id |
| customerPaid | number | Total amount paid |
| merchantReceivable | number | Merchant side amount |
| installerReceivable | number | Installer side amount |
| currency | string | Fiat currency |
| status | enum | `pending`, `settled`, `review_required` |

## Receipt

| Field | Type | Notes |
| --- | --- | --- |
| id | string | Receipt id |
| paymentIntentId | string | Related payment intent |
| receiptNumber | string | Human-readable receipt number |
| customerName | string | Customer name |
| lineItems | array | Payment line items |
| totalPaid | number | Total fiat amount |
| btcAmount | string | BTC amount if available |
| paymentMethod | string | Payment method |
| issuedAt | datetime | Receipt issue time |

