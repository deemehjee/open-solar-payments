# Security Notes

Payment systems touch sensitive financial workflows. This module should be implemented with conservative defaults.

## Do Not Store Private Keys

The module should not store Bitcoin private keys. It should integrate with external wallets, BTCPay Server, Lightning providers, or controlled infrastructure.

## Verify Webhooks

Every webhook should be verified where the provider supports signatures.

Validation should include:

- signature verification
- timestamp tolerance
- event idempotency
- known invoice id
- expected amount
- expected status transition

## Idempotency

All webhook processing must be idempotent. Duplicate provider events should not create duplicate receipts, settlements, or workorders.

## Amount Mismatch Handling

Underpayment, overpayment, late payment, or expired invoice payment should move the payment into `review_required`.

## Least Privilege

The payment module should have only the access it needs:

- create and read payment records
- update payment status
- notify host app
- create settlement records

It should not have unnecessary access to host-app admin data.

## Sensitive Data

Avoid storing unnecessary personal data. Use host-app user ids where possible.

## Public Repository Hygiene

Never commit:

- API keys
- wallet seeds
- webhook secrets
- SMTP credentials
- production database URLs
- private Suntecorb application code

## Production Recommendations

- Use HTTPS only.
- Use strong webhook secrets.
- Rotate secrets regularly.
- Keep audit logs for payment state changes.
- Separate testnet/signet and mainnet configuration.
- Provide manual review tools for mismatched payments.

