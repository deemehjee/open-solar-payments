# Integration Guide

This guide shows how a solar platform can integrate Open Solar Payments without rewriting its product, quote, installer, or workorder systems.

## Integration Steps

### 1. Create a Quote or Cart

The host platform calculates the solar quote, shop cart, installer booking, or finance deposit.

Example sources:

- PowerLoad system quote
- Shop checkout
- Installer booking
- SunSplash deposit
- Workorder settlement

### 2. Create a Payment Intent

Send the amount, reference, source type, and metadata to the payment module.

### 3. Create a Bitcoin or Lightning Invoice

The user selects a payment method.

The module creates the invoice and returns:

- payment request
- QR payload
- expiry time
- amount in sats or BTC
- invoice id

### 4. Display Invoice to User

The host app displays the Lightning invoice or Bitcoin payment URI.

### 5. Receive Webhook

The payment provider sends a webhook to the payment module.

The module validates and updates the payment status.

### 6. Notify Host App

The module sends a host-app webhook:

```json
{
  "event": "payment.confirmed",
  "paymentIntentId": "pi_01JZ_SOLAR",
  "sourceType": "solar_quote",
  "sourceId": "quote_123",
  "status": "confirmed"
}
```

### 7. Update Solar Workflow

The host app can now:

- mark order as paid
- create receipt
- create installer workorder
- release order to fulfillment
- record installer settlement

## Suntecorb Reference Implementation

Suntecorb can map payment sources like this:

| Suntecorb Flow | Payment Source Type |
| --- | --- |
| PowerLoad full payment | `solar_quote` |
| Shop checkout | `shop_cart` |
| SunSplash upfront deposit | `sunsplash_deposit` |
| Installer booking | `installer_booking` |
| Workorder settlement | `workorder` |

## Deployment Pattern

Recommended deployment:

- Host app owns user login and quote generation.
- Payment module runs as a separate service or package.
- Payment module stores invoice, event, receipt, and settlement data.
- Host app receives trusted payment status updates.

