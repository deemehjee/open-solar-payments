# Grant Email Draft

Subject: Grant Proposal: Open-Source Bitcoin Payment Rails for Solar Access

Hello Spiral team,

My name is [Your Name], founder of Suntecorb, a solar design, component shopping, installer booking, and workorder platform built to make solar adoption less fragmented in emerging markets.

I am writing to propose Open Solar Payments, an open-source Bitcoin and Lightning payment module for solar commerce and installer settlement.

The project is designed to help solar merchants, installers, and energy platforms accept Bitcoin and Lightning payments, track invoice status, generate receipts, and connect confirmed payments to real-world solar orders and installer workorders.

Suntecorb will serve as the first real-world implementation, but the payment module itself is designed to be reusable by other solar businesses, community energy projects, and developers building Bitcoin commerce tools for practical services.

We have already completed Milestone 1: the public architecture, API shape, payment lifecycle, data model, integration guide, OpenAPI draft, example payloads, and roadmap.

Milestone 1 repository:
[Insert public GitHub repository link]

Suntecorb live site:
https://suntecorb.one

The grant would support the next stages:

1. Implement Bitcoin and Lightning invoice adapters.
2. Add payment status tracking and webhook verification.
3. Connect receipts to solar orders and installer workorders.
4. Publish reference integration notes from Suntecorb.
5. Document the implementation so other energy merchants can reuse it.

This work aligns with Spiral's support for free and open-source Bitcoin projects by helping Bitcoin become usable in a practical, high-need sector: energy access.

I would be grateful to share a fuller technical scope, budget, and development timeline.

Thank you for your consideration.

Best regards,

[Your Name]  
Founder, Suntecorb  
https://suntecorb.one  
[Your Email]

