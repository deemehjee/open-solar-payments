# Open Solar Payments

Open Solar Payments is an open-source architecture and API specification for Bitcoin and Lightning payment rails in solar commerce, installer workorders, and energy-service settlement.

The first planned reference implementation is Suntecorb, a solar design, component shopping, installer booking, and workorder platform for emerging markets.

This repository is intentionally scoped to the reusable payment module. It does not expose the private Suntecorb application source code.

## Why This Exists

Solar adoption in many emerging markets is slowed by fragmented quotations, manual payment confirmation, installer uncertainty, and weak settlement records. Bitcoin and Lightning can help energy merchants accept borderless payments, issue auditable receipts, and reconcile installer workorders without forcing every solar platform to invent its own payment layer.

Open Solar Payments defines a reusable module for:

- Bitcoin and Lightning invoice creation
- Payment status tracking
- Webhook confirmation
- Solar quote and checkout settlement
- Installer workorder settlement records
- Receipt generation
- Merchant and installer reconciliation
- Integration documentation for solar businesses

## Grant-Relevant Scope

This Milestone 1 package includes:

- Architecture overview
- API shape
- Payment lifecycle
- Data model
- Webhook flow
- Security notes
- Integration guide
- Example JSON payloads
- OpenAPI draft
- 90-day roadmap

## What Is Open Source

The reusable payment module specification is open source:

- API contracts
- Payment lifecycle states
- Webhook event structure
- Invoice and receipt model
- Workorder settlement model
- Integration guidance

## What Remains Private

Suntecorb's full production application, vendor inventory logic, private admin flows, credentials, customer data, and deployment infrastructure remain private.

## Intended Users

- Solar marketplaces
- Solar installers
- Energy merchants
- Off-grid equipment shops
- Community energy projects
- Developers building Bitcoin commerce tools for real-world services

## Documentation

- [Architecture](docs/architecture.md)
- [API Specification](docs/api.md)
- [Payment Lifecycle](docs/payment-lifecycle.md)
- [Data Model](docs/data-model.md)
- [Integration Guide](docs/integration-guide.md)
- [Security Notes](docs/security.md)
- [Roadmap](docs/roadmap.md)
- [Spiral Grant Summary](docs/spiral-grant-summary.md)
- [OpenAPI Draft](openapi/openapi.yaml)
- [Example Payloads](examples/)

## Status

Milestone 1: Architecture and specification draft.

Next milestones:

1. Implement Bitcoin and Lightning invoice adapters.
2. Add payment status polling and webhook verification.
3. Connect receipts to solar orders and installer workorders.
4. Publish reference integration notes from Suntecorb.

## License

MIT License. See [LICENSE](LICENSE).

