# Spiral Grant Summary

## Project Title

Open-Source Bitcoin Payment Rails for Solar Access in Emerging Markets

## Short Description

Open Solar Payments is a reusable open-source Bitcoin and Lightning payment module for solar commerce, installer workorders, and energy-service settlement. Suntecorb will serve as the first real-world implementation.

## Problem

Solar buyers in emerging markets often face fragmented quotations, weak payment confirmation, unclear installer settlement, and limited cross-border payment options. Energy merchants and installers also lack simple open-source tools for Bitcoin and Lightning payment workflows tied to real service delivery.

## Proposed Solution

Build and publish an open-source Bitcoin and Lightning payment module that supports:

- solar quote checkout
- component cart checkout
- installer booking payments
- workorder settlement records
- invoice status tracking
- receipt generation
- merchant and installer reconciliation

## Why Bitcoin and Lightning

Bitcoin and Lightning can provide borderless payment rails, quick settlement, and a practical alternative for merchants and customers in markets where payment reliability, currency movement, and reconciliation are difficult.

## Why Suntecorb

Suntecorb is already a live solar workflow platform that connects system design, component shopping, installer booking, and workorders. It can provide the first pilot environment while the reusable payment module remains open for others.

## Open-Source Deliverables

- Payment module architecture
- API contracts
- OpenAPI specification
- Lightning invoice workflow
- BTCPay-compatible workflow
- Webhook handling model
- Receipt and settlement model
- Integration documentation
- Reference implementation notes

## What Funding Supports

Funding would support implementation, testing, documentation, and reference integration of the open-source Bitcoin payment module.

## Public Good

The module can be reused by solar merchants, community energy projects, installers, and developers building Bitcoin commerce tools for real-world services.

