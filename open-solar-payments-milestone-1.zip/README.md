# Open Solar Payments

Open Solar Payments is a proposed free and open-source Bitcoin/Lightning payment module for solar commerce and installer settlement in emerging markets.

The module is designed to help solar merchants, installers, energy marketplaces, and small businesses accept Bitcoin/Lightning payments, track invoice status, issue receipts, and connect confirmed payments to solar orders and installer workorders.

Suntecorb is the first reference implementation and pilot environment. The grant-funded work is not a request to fund Suntecorb's private marketplace code. The public deliverable is reusable Bitcoin/Lightning payment infrastructure that other solar and energy businesses can adopt.

## Milestone 1 Status

Milestone 1 is complete when the project has a public architecture, API shape, data model, integration guide, and reference implementation plan. This package provides those documents:

- [ARCHITECTURE.md](ARCHITECTURE.md)
- [API_SPEC.md](API_SPEC.md)
- [DATA_MODEL.md](DATA_MODEL.md)
- [INTEGRATION_GUIDE.md](INTEGRATION_GUIDE.md)
- [REFERENCE_IMPLEMENTATION_PLAN.md](REFERENCE_IMPLEMENTATION_PLAN.md)
- [GRANT_READINESS_CHECKLIST.md](GRANT_READINESS_CHECKLIST.md)

## Bitcoin-First Scope

The module focuses on Bitcoin and Lightning. Other payment rails may exist inside a merchant application, but they are outside the grant-funded open-source scope.

The initial implementation may support Lightning backends such as BTCPay Server or LNbits through adapter interfaces. The module should avoid vendor lock-in and keep payment records portable.

## Intended Users

- Solar component merchants
- Solar installers
- Energy access platforms
- Local service marketplaces
- Small businesses that need Bitcoin/Lightning checkout, receipts, and settlement records

## Core Deliverables

- Lightning invoice checkout flow
- Bitcoin/Lightning payment status API
- Receipt generation
- Installer settlement records tied to workorders
- Merchant integration documentation
- Suntecorb reference implementation plan

## License Recommendation

Recommended license: MIT or Apache-2.0.

The final license should be chosen before publishing the first public repository. MIT is simpler for broad merchant adoption. Apache-2.0 gives explicit patent language.
