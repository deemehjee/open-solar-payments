# Roadmap

## Milestone 1: Architecture and API Specification

Status: draft complete.

Deliverables:

- Architecture overview
- API shape
- Payment lifecycle
- Data model
- Security notes
- Integration guide
- OpenAPI draft
- Example JSON payloads

## Milestone 2: Bitcoin and Lightning Invoice Prototype

Target deliverables:

- Lightning invoice adapter
- BTCPay-compatible adapter
- Payment intent persistence
- Invoice expiration handling
- Provider webhook receiver
- Local development guide

## Milestone 3: Solar Workflow Reference Integration

Target deliverables:

- Suntecorb reference integration notes
- PowerLoad quote payment flow
- Shop cart payment flow
- Installer booking payment flow
- Receipt generation
- Workorder settlement record

## Milestone 4: Documentation, Testing, and Public Demo

Target deliverables:

- Testnet or signet demo
- Integration examples
- Security review checklist
- Merchant onboarding guide
- Public demo video or screenshots
- Lessons from real-world pilot

## 90-Day Grant Timeline

### Days 1 to 30

Finalize specification, choose provider adapters, implement payment intent and invoice primitives.

### Days 31 to 60

Add webhooks, receipts, settlement records, and testnet integration.

### Days 61 to 90

Connect reference implementation, publish documentation, collect pilot feedback, and prepare maintainer roadmap.

