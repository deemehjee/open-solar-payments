# Publishing Checklist

Use this checklist before sharing the project with Spiral or any grant reviewer.

## 1. Create Public Repository

Suggested repository name:

`open-solar-payments`

Suggested description:

`Open-source Bitcoin and Lightning payment rails for solar commerce, installer workorders, and energy-service settlement.`

## 2. Push Only This Folder

Do not push the private Suntecorb application source code.

Public repository contents should include:

- `README.md`
- `LICENSE`
- `docs/`
- `examples/`
- `openapi/`
- `PUBLISHING.md`

## 3. Confirm No Secrets

Before publishing, scan for:

- private keys
- wallet seeds
- webhook secrets
- SMTP credentials
- database URLs
- API keys
- admin passwords
- production IP addresses

## 4. Add Repository Topics

Suggested topics:

- bitcoin
- lightning
- btcpay
- solar
- energy-access
- payments
- open-source
- emerging-markets
- workorders
- settlement

## 5. Update Grant Email

After the repository is public, replace:

`[Insert public GitHub repository link]`

with the actual repo URL.

## 6. Send to Spiral

Send the email draft in `docs/grant-email-draft.md` to:

`grants@spiral.xyz`

## 7. Keep Suntecorb Private

Suntecorb can remain the private production app while Open Solar Payments remains the open-source grant/public-good module.

