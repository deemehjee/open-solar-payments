# Grant Readiness Checklist

This checklist confirms whether Milestone 1 supports a Spiral grant request.

## Bitcoin-First Purpose

Status: Complete

The project is framed as open-source Bitcoin/Lightning payment infrastructure for solar commerce, not a request to fund Suntecorb's private startup development.

## Open-Source Component

Status: Complete

The proposed public module includes architecture, API shape, data model, provider adapter interface, receipts, settlement records, and integration documentation.

## Real-World Adoption Path

Status: Complete

Suntecorb is the first reference implementation and pilot environment. The module is designed to be reusable by other solar merchants, installers, energy platforms, and small businesses.

## Clear Deliverables

Status: Complete

Milestone 1 deliverables now include:

- Architecture documentation
- API specification
- Data model
- Integration guide
- Suntecorb reference implementation plan
- Grant readiness checklist

Future implementation deliverables include:

- Lightning invoice checkout
- Payment status tracking
- Receipt generation
- Installer settlement records
- BTCPay-compatible adapter
- Demo flow and lessons learned

## Public-Good Value

Status: Complete

The module is designed so other solar installers, energy merchants, small businesses, and emerging-market commerce platforms can reuse the Bitcoin/Lightning payment layer.

## Measurable Milestones

Status: Complete

The 30/60/90-day roadmap can now be stated as:

- Days 1-30: publish architecture, API shape, data model, integration guide, and reference implementation plan.
- Days 31-60: implement Lightning invoice checkout, payment status tracking, and receipts.
- Days 61-90: connect confirmed payments to solar orders, installer workorders, and admin reconciliation; publish demo and lessons learned.

## Sustainability

Status: Complete

Suntecorb has a direct incentive to maintain the module after the grant because it supports its own solar commerce workflow while remaining reusable by others.

## No Altcoin Confusion

Status: Complete

The module is Bitcoin/Lightning-first. Other payment rails may exist as private app context, but they are not part of the grant-funded scope.

## Honest Milestone 1 Claim

The project can now honestly claim:

> Milestone 1 is complete: the open-source Bitcoin/Lightning solar payments module now has a publishable architecture, API shape, data model, merchant integration guide, and Suntecorb reference implementation plan.

## Remaining Before Emailing Spiral

- Add the public page link: https://suntecorb.one/open-solar-payments
- Add the future public repository link when available.
- Add applicant name and contact email.
- Add grant amount or ask whether Spiral prefers a budget discussion first.
- Optionally add screenshots or a short demo outline after Milestone 2 begins.
