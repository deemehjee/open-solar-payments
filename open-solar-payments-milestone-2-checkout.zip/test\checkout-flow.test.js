import assert from "node:assert/strict";
import { CheckoutService } from "../src/checkout-service.js";
import { InMemoryStore } from "../src/in-memory-store.js";
import { MockLightningProvider } from "../src/mock-lightning-provider.js";
import { ReceiptService } from "../src/receipt-service.js";
import { InvoiceStatus, PaymentRequestStatus } from "../src/status.js";

function createHarness(currentTime = "2026-07-01T11:30:00Z") {
  const now = () => new Date(currentTime);
  const store = new InMemoryStore();
  const provider = new MockLightningProvider({ now });
  const receiptService = new ReceiptService({ now });
  const checkout = new CheckoutService({ store, provider, receiptService, now });
  return { checkout, provider };
}

function createSolarPaymentRequest(checkout, expiresInSeconds = 1800) {
  return checkout.createPaymentRequest({
    sourceType: "solar_quote",
    sourceId: "quote_456",
    customerRef: "customer_789",
    merchantRef: "merchant_suntecorb",
    description: "Deposit for 5kVA solar system",
    amountSats: 185000,
    displayAmount: {
      amount: 250000,
      currency: "NGN"
    },
    expiresInSeconds
  });
}

{
  const { checkout, provider } = createHarness();
  const paymentRequest = createSolarPaymentRequest(checkout);
  const invoice = await checkout.createInvoice(paymentRequest.id);

  assert.equal(invoice.status, InvoiceStatus.PENDING);
  assert.equal(invoice.amountSats, 185000);
  assert.ok(invoice.bolt11.startsWith("lnbc"));

  await provider.markPaid(invoice.providerInvoiceId, "2026-07-01T11:42:00Z");
  const state = await checkout.handlePaymentWebhook({
    providerEventId: "evt_test_paid_001",
    providerInvoiceId: invoice.providerInvoiceId,
    status: InvoiceStatus.PAID,
    amountSats: invoice.amountSats,
    paidAt: "2026-07-01T11:42:00Z"
  });

  assert.equal(state.paymentRequest.status, PaymentRequestStatus.PAID);
  assert.equal(state.invoice.status, InvoiceStatus.PAID);
  assert.equal(state.receipt.amountSats, 185000);
  assert.equal(state.receipt.sourceId, "quote_456");
}

{
  const { checkout } = createHarness();
  const paymentRequest = createSolarPaymentRequest(checkout, -1);
  const state = checkout.getCheckoutState(paymentRequest.id);

  assert.equal(state.paymentRequest.status, PaymentRequestStatus.EXPIRED);
  assert.equal(state.checkout.canPay, false);
}

{
  const { checkout, provider } = createHarness();
  const paymentRequest = createSolarPaymentRequest(checkout);
  const invoice = await checkout.createInvoice(paymentRequest.id);

  await provider.markPaid(invoice.providerInvoiceId, "2026-07-01T11:42:00Z");
  const payload = {
    providerEventId: "evt_test_paid_duplicate",
    providerInvoiceId: invoice.providerInvoiceId,
    status: InvoiceStatus.PAID,
    amountSats: invoice.amountSats,
    paidAt: "2026-07-01T11:42:00Z"
  };

  const firstState = await checkout.handlePaymentWebhook(payload);
  const secondState = await checkout.handlePaymentWebhook(payload);

  assert.equal(firstState.receipt.id, secondState.receipt.id);
  assert.equal(secondState.paymentRequest.status, PaymentRequestStatus.PAID);
}

console.log("checkout-flow.test.js passed");
