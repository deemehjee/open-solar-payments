# Milestone 2: Bitcoin/Lightning Checkout

This package implements the first working checkout lifecycle for Open Solar Payments.

It proves the Milestone 2 deliverables:

- Lightning invoice generation
- Checkout payment state
- Payment expiry handling
- Payment confirmation flow
- Basic receipt generation

The implementation uses a provider adapter interface and a mock Lightning provider so the flow can be tested without live BTCPay Server credentials. A BTCPay adapter can be added behind the same interface.

## Run

```text
npm test
npm run demo
```

## What The Demo Does

1. Creates a payment request for a solar quote deposit.
2. Generates a Lightning-style invoice.
3. Reads checkout state.
4. Simulates payment confirmation from the provider.
5. Generates a receipt.
6. Reads final checkout state.

## Files

```text
src/checkout-service.js
src/in-memory-store.js
src/mock-lightning-provider.js
src/receipt-service.js
src/status.js
demo/run-checkout-demo.js
test/checkout-flow.test.js
```

## Provider Boundary

Any Lightning backend should implement:

```text
createInvoice(paymentRequest)
getInvoiceStatus(providerInvoiceId)
parseWebhook(payload, headers)
verifyWebhook(event)
```

The checkout service should not need to know whether the backend is BTCPay Server, LNbits, or another Lightning-compatible provider.

## Milestone 2 Completion Claim

Once the tests and demo pass, the project can claim:

> Milestone 2 has a working checkout scaffold: it creates Bitcoin/Lightning payment requests and invoices, tracks checkout state, handles invoice expiry, processes payment confirmation, and generates a basic receipt.
