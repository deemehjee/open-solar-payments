import { InvoiceStatus } from "./status.js";

export class MockLightningProvider {
  constructor({ now = () => new Date() } = {}) {
    this.now = now;
    this.providerInvoices = new Map();
    this.nextId = 1;
  }

  async createInvoice(paymentRequest) {
    const providerInvoiceId = `mock_inv_${this.nextId++}`;
    const invoice = {
      provider: "mock-lightning",
      providerInvoiceId,
      status: InvoiceStatus.PENDING,
      amountSats: paymentRequest.amountSats,
      bolt11: `lnbc${paymentRequest.amountSats}n1mock${providerInvoiceId}`,
      checkoutUrl: `https://pay.example.test/checkout/${providerInvoiceId}`,
      expiresAt: paymentRequest.expiresAt,
      createdAt: this.now().toISOString()
    };

    this.providerInvoices.set(providerInvoiceId, invoice);
    return invoice;
  }

  async getInvoiceStatus(providerInvoiceId) {
    const invoice = this.providerInvoices.get(providerInvoiceId);
    if (!invoice) return { status: InvoiceStatus.FAILED };
    return {
      status: invoice.status,
      paidAt: invoice.paidAt || null
    };
  }

  async markPaid(providerInvoiceId, paidAt = this.now().toISOString()) {
    const invoice = this.providerInvoices.get(providerInvoiceId);
    if (!invoice) throw new Error(`Unknown provider invoice: ${providerInvoiceId}`);
    invoice.status = InvoiceStatus.PAID;
    invoice.paidAt = paidAt;
    this.providerInvoices.set(providerInvoiceId, invoice);
    return invoice;
  }

  parseWebhook(payload) {
    return {
      provider: "mock-lightning",
      providerEventId: payload.providerEventId,
      providerInvoiceId: payload.providerInvoiceId,
      status: payload.status,
      amountSats: payload.amountSats,
      paidAt: payload.paidAt
    };
  }

  verifyWebhook(event) {
    return Boolean(event.providerEventId && event.providerInvoiceId && event.status);
  }
}
