import { CheckoutService } from "../src/checkout-service.js";
import { InMemoryStore } from "../src/in-memory-store.js";
import { MockLightningProvider } from "../src/mock-lightning-provider.js";
import { ReceiptService } from "../src/receipt-service.js";
import { InvoiceStatus } from "../src/status.js";

const now = () => new Date("2026-07-01T11:30:00Z");
const store = new InMemoryStore();
const provider = new MockLightningProvider({ now });
const receiptService = new ReceiptService({ now });
const checkout = new CheckoutService({ store, provider, receiptService, now });

const paymentRequest = checkout.createPaymentRequest({
  sourceType: "solar_quote",
  sourceId: "quote_456",
  customerRef: "customer_789",
  merchantRef: "merchant_suntecorb",
  description: "Deposit for 5kVA solar system",
  amountSats: 185000,
  displayAmount: {
    amount: 250000,
    currency: "NGN"
  },
  expiresInSeconds: 1800,
  metadata: {
    market: "Nigeria",
    orderType: "deposit"
  }
});

const invoice = await checkout.createInvoice(paymentRequest.id);
await provider.markPaid(invoice.providerInvoiceId, "2026-07-01T11:42:00Z");

const finalState = await checkout.handlePaymentWebhook({
  providerEventId: "evt_demo_paid_001",
  providerInvoiceId: invoice.providerInvoiceId,
  status: InvoiceStatus.PAID,
  amountSats: invoice.amountSats,
  paidAt: "2026-07-01T11:42:00Z"
});

console.log(JSON.stringify({
  paymentRequestId: finalState.paymentRequest.id,
  invoiceId: finalState.invoice.id,
  checkoutStatus: finalState.checkout.status,
  bolt11: finalState.invoice.bolt11,
  checkoutUrl: finalState.invoice.checkoutUrl,
  receipt: finalState.receipt
}, null, 2));
