import { InvoiceStatus, PaymentRequestStatus, isTerminalStatus } from "./status.js";

export class CheckoutService {
  constructor({ store, provider, receiptService, now = () => new Date() }) {
    this.store = store;
    this.provider = provider;
    this.receiptService = receiptService;
    this.now = now;
    this.nextPaymentRequestId = 1;
    this.nextInvoiceId = 1;
  }

  createPaymentRequest(input) {
    if (!input.sourceType || !input.sourceId) {
      throw new Error("sourceType and sourceId are required");
    }
    if (!Number.isInteger(input.amountSats) || input.amountSats <= 0) {
      throw new Error("amountSats must be a positive integer");
    }

    const createdAt = this.now();
    const expiresInSeconds = input.expiresInSeconds || 1800;
    const expiresAt = new Date(createdAt.getTime() + expiresInSeconds * 1000);
    const paymentRequest = {
      id: `payreq_${this.nextPaymentRequestId++}`,
      sourceType: input.sourceType,
      sourceId: input.sourceId,
      customerRef: input.customerRef || null,
      merchantRef: input.merchantRef || null,
      description: input.description || "",
      amountSats: input.amountSats,
      displayAmount: input.displayAmount || null,
      status: PaymentRequestStatus.PENDING,
      invoiceId: null,
      receiptId: null,
      expiresAt: expiresAt.toISOString(),
      createdAt: createdAt.toISOString(),
      updatedAt: createdAt.toISOString(),
      metadata: input.metadata || {}
    };

    return this.store.savePaymentRequest(paymentRequest);
  }

  async createInvoice(paymentRequestId) {
    const paymentRequest = this.requirePaymentRequest(paymentRequestId);
    this.expireIfNeeded(paymentRequest);

    if (paymentRequest.status === PaymentRequestStatus.EXPIRED) {
      throw new Error("Cannot create invoice for expired payment request");
    }
    if (paymentRequest.invoiceId) {
      return this.requireInvoice(paymentRequest.invoiceId);
    }

    const providerInvoice = await this.provider.createInvoice(paymentRequest);
    const nowIso = this.now().toISOString();
    const invoice = {
      id: `inv_${this.nextInvoiceId++}`,
      paymentRequestId: paymentRequest.id,
      provider: providerInvoice.provider,
      providerInvoiceId: providerInvoice.providerInvoiceId,
      status: providerInvoice.status,
      amountSats: providerInvoice.amountSats,
      bolt11: providerInvoice.bolt11,
      checkoutUrl: providerInvoice.checkoutUrl,
      expiresAt: providerInvoice.expiresAt,
      paidAt: null,
      createdAt: nowIso,
      updatedAt: nowIso
    };

    this.store.saveInvoice(invoice);
    paymentRequest.invoiceId = invoice.id;
    paymentRequest.updatedAt = nowIso;
    this.store.savePaymentRequest(paymentRequest);
    return invoice;
  }

  getCheckoutState(paymentRequestId) {
    const paymentRequest = this.requirePaymentRequest(paymentRequestId);
    this.expireIfNeeded(paymentRequest);
    const invoice = paymentRequest.invoiceId ? this.requireInvoice(paymentRequest.invoiceId) : null;
    const receipt = paymentRequest.receiptId ? this.store.getReceipt(paymentRequest.receiptId) : null;

    return {
      paymentRequest,
      invoice,
      receipt,
      checkout: {
        status: paymentRequest.status,
        canPay: paymentRequest.status === PaymentRequestStatus.PENDING,
        expiresAt: paymentRequest.expiresAt
      }
    };
  }

  async refreshInvoiceStatus(invoiceId) {
    const invoice = this.requireInvoice(invoiceId);
    const paymentRequest = this.requirePaymentRequest(invoice.paymentRequestId);
    this.expireIfNeeded(paymentRequest, invoice);

    if (isTerminalStatus(paymentRequest.status)) {
      return this.getCheckoutState(paymentRequest.id);
    }

    const providerStatus = await this.provider.getInvoiceStatus(invoice.providerInvoiceId);
    if (providerStatus.status === InvoiceStatus.PAID) {
      return this.confirmPaidInvoice({
        invoice,
        paymentRequest,
        paidAt: providerStatus.paidAt || this.now().toISOString()
      });
    }

    return this.getCheckoutState(paymentRequest.id);
  }

  async handlePaymentWebhook(payload, headers = {}) {
    const event = this.provider.parseWebhook(payload, headers);
    if (!this.provider.verifyWebhook(event)) {
      throw new Error("Invalid payment webhook");
    }
    if (this.store.hasEvent(event.providerEventId)) {
      const invoice = this.store.findInvoiceByProviderInvoiceId(event.providerInvoiceId);
      return invoice ? this.getCheckoutState(invoice.paymentRequestId) : { duplicate: true };
    }

    this.store.saveEvent({
      id: event.providerEventId,
      provider: event.provider,
      providerEventId: event.providerEventId,
      providerInvoiceId: event.providerInvoiceId,
      status: "received",
      receivedAt: this.now().toISOString()
    });

    const invoice = this.store.findInvoiceByProviderInvoiceId(event.providerInvoiceId);
    if (!invoice) throw new Error("Webhook invoice not found");
    const paymentRequest = this.requirePaymentRequest(invoice.paymentRequestId);

    if (event.status !== InvoiceStatus.PAID) {
      return this.getCheckoutState(paymentRequest.id);
    }

    return this.confirmPaidInvoice({
      invoice,
      paymentRequest,
      paidAt: event.paidAt || this.now().toISOString()
    });
  }

  confirmPaidInvoice({ invoice, paymentRequest, paidAt }) {
    if (paymentRequest.status === PaymentRequestStatus.PAID && paymentRequest.receiptId) {
      return this.getCheckoutState(paymentRequest.id);
    }

    const nowIso = this.now().toISOString();
    invoice.status = InvoiceStatus.PAID;
    invoice.paidAt = paidAt;
    invoice.updatedAt = nowIso;
    this.store.saveInvoice(invoice);

    paymentRequest.status = PaymentRequestStatus.PAID;
    paymentRequest.updatedAt = nowIso;

    let receipt = this.store.findReceiptByPaymentRequestId(paymentRequest.id);
    if (!receipt) {
      receipt = this.receiptService.createReceipt({ paymentRequest, invoice });
      this.store.saveReceipt(receipt);
    }

    paymentRequest.receiptId = receipt.id;
    this.store.savePaymentRequest(paymentRequest);
    return this.getCheckoutState(paymentRequest.id);
  }

  expireIfNeeded(paymentRequest, invoice = null) {
    if (isTerminalStatus(paymentRequest.status)) return;
    if (new Date(paymentRequest.expiresAt).getTime() > this.now().getTime()) return;

    const nowIso = this.now().toISOString();
    paymentRequest.status = PaymentRequestStatus.EXPIRED;
    paymentRequest.updatedAt = nowIso;
    this.store.savePaymentRequest(paymentRequest);

    const linkedInvoice = invoice || (paymentRequest.invoiceId ? this.store.getInvoice(paymentRequest.invoiceId) : null);
    if (linkedInvoice && linkedInvoice.status === InvoiceStatus.PENDING) {
      linkedInvoice.status = InvoiceStatus.EXPIRED;
      linkedInvoice.updatedAt = nowIso;
      this.store.saveInvoice(linkedInvoice);
    }
  }

  requirePaymentRequest(id) {
    const paymentRequest = this.store.getPaymentRequest(id);
    if (!paymentRequest) throw new Error(`Payment request not found: ${id}`);
    return paymentRequest;
  }

  requireInvoice(id) {
    const invoice = this.store.getInvoice(id);
    if (!invoice) throw new Error(`Invoice not found: ${id}`);
    return invoice;
  }
}
