export class InMemoryStore {
  constructor() {
    this.paymentRequests = new Map();
    this.invoices = new Map();
    this.receipts = new Map();
    this.events = new Map();
  }

  savePaymentRequest(paymentRequest) {
    this.paymentRequests.set(paymentRequest.id, paymentRequest);
    return paymentRequest;
  }

  getPaymentRequest(id) {
    return this.paymentRequests.get(id) || null;
  }

  saveInvoice(invoice) {
    this.invoices.set(invoice.id, invoice);
    return invoice;
  }

  getInvoice(id) {
    return this.invoices.get(id) || null;
  }

  findInvoiceByProviderInvoiceId(providerInvoiceId) {
    for (const invoice of this.invoices.values()) {
      if (invoice.providerInvoiceId === providerInvoiceId) return invoice;
    }
    return null;
  }

  saveReceipt(receipt) {
    this.receipts.set(receipt.id, receipt);
    return receipt;
  }

  getReceipt(id) {
    return this.receipts.get(id) || null;
  }

  findReceiptByPaymentRequestId(paymentRequestId) {
    for (const receipt of this.receipts.values()) {
      if (receipt.paymentRequestId === paymentRequestId) return receipt;
    }
    return null;
  }

  saveEvent(event) {
    this.events.set(event.id, event);
    return event;
  }

  hasEvent(providerEventId) {
    return this.events.has(providerEventId);
  }
}
