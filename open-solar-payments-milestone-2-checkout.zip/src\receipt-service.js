export class ReceiptService {
  constructor({ now = () => new Date() } = {}) {
    this.now = now;
    this.nextReceiptNumber = 1;
  }

  createReceipt({ paymentRequest, invoice }) {
    const sequence = String(this.nextReceiptNumber++).padStart(6, "0");
    return {
      id: `receipt_${paymentRequest.id}`,
      receiptNumber: `OSP-${this.now().getUTCFullYear()}-${sequence}`,
      paymentRequestId: paymentRequest.id,
      invoiceId: invoice.id,
      sourceType: paymentRequest.sourceType,
      sourceId: paymentRequest.sourceId,
      customerRef: paymentRequest.customerRef,
      merchantRef: paymentRequest.merchantRef,
      amountSats: paymentRequest.amountSats,
      displayAmount: paymentRequest.displayAmount,
      paidAt: invoice.paidAt,
      issuedAt: this.now().toISOString()
    };
  }
}
