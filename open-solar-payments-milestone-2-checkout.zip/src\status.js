export const PaymentRequestStatus = Object.freeze({
  PENDING: "pending",
  PAID: "paid",
  EXPIRED: "expired",
  FAILED: "failed",
  CANCELLED: "cancelled"
});

export const InvoiceStatus = Object.freeze({
  PENDING: "pending",
  PAID: "paid",
  EXPIRED: "expired",
  FAILED: "failed",
  CANCELLED: "cancelled"
});

export function isTerminalStatus(status) {
  return [
    PaymentRequestStatus.PAID,
    PaymentRequestStatus.EXPIRED,
    PaymentRequestStatus.FAILED,
    PaymentRequestStatus.CANCELLED
  ].includes(status);
}
