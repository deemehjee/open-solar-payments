# Verification

## Date

2026-06-26

## Test Command

```text
node .\test\checkout-flow.test.js
```

Result:

```text
checkout-flow.test.js passed
```

## Demo Command

```text
node .\demo\run-checkout-demo.js
```

Confirmed output:

```json
{
  "paymentRequestId": "payreq_1",
  "invoiceId": "inv_1",
  "checkoutStatus": "paid",
  "bolt11": "lnbc185000n1mockmock_inv_1",
  "checkoutUrl": "https://pay.example.test/checkout/mock_inv_1",
  "receipt": {
    "id": "receipt_payreq_1",
    "receiptNumber": "OSP-2026-000001",
    "paymentRequestId": "payreq_1",
    "invoiceId": "inv_1",
    "sourceType": "solar_quote",
    "sourceId": "quote_456",
    "customerRef": "customer_789",
    "merchantRef": "merchant_suntecorb",
    "amountSats": 185000,
    "displayAmount": {
      "amount": 250000,
      "currency": "NGN"
    },
    "paidAt": "2026-07-01T11:42:00Z",
    "issuedAt": "2026-07-01T11:30:00.000Z"
  }
}
```

## Coverage

- Invoice creation: verified
- Checkout state: verified
- Expiry handling: verified by test
- Payment confirmation: verified by webhook test and demo
- Receipt generation: verified by test and demo
- Duplicate webhook idempotency: verified by test

## Note

The commands required unsandboxed execution because Node attempted to resolve the parent user directory during startup inside the managed sandbox. The code itself has no external dependencies and does not require network access.
